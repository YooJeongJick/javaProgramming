public class Video extends Product{
	Video() {
		super(70);
	}
	
	public String toString() { 
		// Object 클래스에 정의된 toString()을 재정의함!
		return "비디오";
	}

}
