public class Audio extends Product {
	Audio() {
		super(120);
	}
	
	public String toString() { 
		// Object 클래스에 정의된 toString()을 재정의함!
		return "오디오";
	}
}
