public class Radio extends Product {
	Radio() {
		super(150);
	}
	
	public String toString() { 
		// Object 클래스에 정의된 toString()을 재정의함!
		return "라디오";
	}

}
