package aa.bb; // 패키지 정의시 맨 첫 문장에 작성!!

import java.util.*;

public class Test2 {

	public static void main(String[] args) {

	}

}
